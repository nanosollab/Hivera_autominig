const banner = `\x1b[33mTool (https://t.me/D4rkCipherX) \x1b[0m \n`;

export default banner;
