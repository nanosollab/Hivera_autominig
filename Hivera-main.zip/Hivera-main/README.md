## HIVERA BOT

## BOT FEATURE

- Auto Mining
- Auto Task
- Proxy Support
- Multiple Account

## COOMANDS
```
pkg install nodejs-lts
```
```
pkg install git
```
   ```bash
   git clone https://github.com/Not-D4rkCipherX/Hivera.git
   ```
   ```bash
   cd Hivera
   ```

2. **Instal Requirements:**
   ```bash
   npm i
   ```
3. **ADD ACCOUNTS**
   ```
   nano data.txt
   ```
4.**START THE BOT**
```bash
node hivera.js
```
For Proxy :
```
node hivera-proxy.js
```
For those using multiple accounts, it's recommended to use a proxy (if using only one account, there's no need to create the proxy.txt file).

---

## PROXY FORMAT

```bash
http://username:passwoord@hostname:port
socks5://username:password@hostname:port
```
**TUTORIAL AVAILABLE ON MY YT**
